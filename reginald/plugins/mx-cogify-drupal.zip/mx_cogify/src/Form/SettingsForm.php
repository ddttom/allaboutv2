<?php

namespace Drupal\mx_cogify\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * MX Cogify settings form.
 *
 * @mx:status draft
 * @mx:contentType product
 * @mx:tags drupal, settings, cogification
 */
class SettingsForm extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return ['mx_cogify.settings'];
  }

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'mx_cogify_settings';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $config = $this->config('mx_cogify.settings');

    // Site information.
    $form['site'] = [
      '#type' => 'details',
      '#title' => $this->t('Site information'),
      '#open' => TRUE,
    ];

    $form['site']['site_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Site name'),
      '#description' => $this->t('Used in Open Graph and Schema.org output. Defaults to the Drupal site name.'),
      '#default_value' => $config->get('site_name'),
    ];

    $form['site']['organisation'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Organisation name'),
      '#description' => $this->t('Used as Schema.org publisher. Defaults to site name.'),
      '#default_value' => $config->get('organisation'),
    ];

    $form['site']['author'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Default author'),
      '#description' => $this->t('Fallback author for meta tags. Per-node author is used when available.'),
      '#default_value' => $config->get('author'),
    ];

    $form['site']['twitter_handle'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Twitter handle'),
      '#description' => $this->t('Include the @ symbol, e.g. @yoursite.'),
      '#default_value' => $config->get('twitter_handle'),
    ];

    $form['site']['language'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Default language'),
      '#description' => $this->t('BCP 47 language code, e.g. en, en-GB, de.'),
      '#default_value' => $config->get('language'),
    ];

    // Images.
    $form['images'] = [
      '#type' => 'details',
      '#title' => $this->t('Default images'),
      '#open' => FALSE,
    ];

    $form['images']['default_og_image'] = [
      '#type' => 'url',
      '#title' => $this->t('Default OG image URL'),
      '#description' => $this->t('Absolute URL to the default image for Open Graph and Twitter Card.'),
      '#default_value' => $config->get('default_og_image'),
    ];

    $form['images']['default_og_image_alt'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Default OG image alt text'),
      '#default_value' => $config->get('default_og_image_alt'),
    ];

    // MX defaults.
    $form['mx'] = [
      '#type' => 'details',
      '#title' => $this->t('MX defaults'),
      '#open' => TRUE,
    ];

    $form['mx']['mx_status'] = [
      '#type' => 'select',
      '#title' => $this->t('Default MX status'),
      '#options' => [
        'active' => $this->t('Active'),
        'draft' => $this->t('Draft'),
        'archived' => $this->t('Archived'),
      ],
      '#default_value' => $config->get('mx_status'),
    ];

    $form['mx']['mx_content_policy'] = [
      '#type' => 'select',
      '#title' => $this->t('Default content policy'),
      '#options' => [
        'extract-with-attribution' => $this->t('Extract with attribution'),
        'summaries-allowed' => $this->t('Summaries allowed'),
        'no-ai-training' => $this->t('No AI training'),
        'restricted' => $this->t('Restricted'),
      ],
      '#default_value' => $config->get('mx_content_policy'),
    ];

    $form['mx']['mx_audience'] = [
      '#type' => 'select',
      '#title' => $this->t('Default audience'),
      '#options' => [
        'humans' => $this->t('Humans'),
        'ai-agents' => $this->t('AI agents'),
        'both' => $this->t('Both'),
      ],
      '#default_value' => $config->get('mx_audience'),
    ];

    // Reginald integration.
    $form['reginald'] = [
      '#type' => 'details',
      '#title' => $this->t('Reginald registration'),
      '#open' => FALSE,
    ];

    $form['reginald']['reginald_api_key'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Reginald API key'),
      '#description' => $this->t('Subscribe at reginald.allabout.network to get your API key.'),
      '#default_value' => $config->get('reginald_api_key'),
    ];

    return parent::buildForm($form, $form_state);
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $this->config('mx_cogify.settings')
      ->set('site_name', $form_state->getValue('site_name'))
      ->set('organisation', $form_state->getValue('organisation'))
      ->set('author', $form_state->getValue('author'))
      ->set('twitter_handle', $form_state->getValue('twitter_handle'))
      ->set('language', $form_state->getValue('language'))
      ->set('default_og_image', $form_state->getValue('default_og_image'))
      ->set('default_og_image_alt', $form_state->getValue('default_og_image_alt'))
      ->set('mx_status', $form_state->getValue('mx_status'))
      ->set('mx_content_policy', $form_state->getValue('mx_content_policy'))
      ->set('mx_audience', $form_state->getValue('mx_audience'))
      ->set('reginald_api_key', $form_state->getValue('reginald_api_key'))
      ->save();

    parent::submitForm($form, $form_state);
  }

}
