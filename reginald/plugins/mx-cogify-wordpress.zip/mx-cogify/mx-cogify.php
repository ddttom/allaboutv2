<?php
/**
 * Plugin Name: MX Cogify
 * Plugin URI:  https://allabout.network/mx-cogify
 * Description: Cogify your WordPress site. Adds MX metadata, Schema.org structured data, and Open Graph tags to every page. Register with Reginald to make your site discoverable by AI agents.
 * Version:     0.1.0
 * Author:      Tom Cranstoun
 * Author URI:  https://allabout.network
 * License:     GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: mx-cogify
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @mx:status draft
 * @mx:contentType product
 * @mx:tags wordpress, plugin, cogification, schema-org
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants.
define( 'MX_COGIFY_VERSION', '0.1.0' );
define( 'MX_COGIFY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MX_COGIFY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MX_COGIFY_PLUGIN_FILE', __FILE__ );

/**
 * Main plugin class.
 */
final class MX_Cogify {

    /**
     * Singleton instance.
     *
     * @var MX_Cogify|null
     */
    private static $instance = null;

    /**
     * Get singleton instance.
     *
     * @return MX_Cogify
     */
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor. Wire up hooks.
     */
    private function __construct() {
        $this->load_includes();
        $this->init_hooks();
    }

    /**
     * Load required files.
     */
    private function load_includes() {
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-conflict-resolver.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-meta-injector.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-schema-generator.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-mx-tags.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-reginald-client.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-manifest-server.php';
        require_once MX_COGIFY_PLUGIN_DIR . 'includes/class-llms-txt.php';

        if ( is_admin() ) {
            require_once MX_COGIFY_PLUGIN_DIR . 'admin/class-settings-page.php';
            require_once MX_COGIFY_PLUGIN_DIR . 'admin/class-post-metabox.php';
        }
    }

    /**
     * Register WordPress hooks.
     */
    private function init_hooks() {
        // Front-end: inject meta tags into <head>.
        add_action( 'wp_head', array( $this, 'inject_meta_tags' ), 1 );

        // Admin: settings page and post metabox.
        if ( is_admin() ) {
            add_action( 'admin_menu', array( 'MX_Cogify_Settings_Page', 'register' ) );
            add_action( 'admin_init', array( 'MX_Cogify_Settings_Page', 'register_settings' ) );
            add_action( 'add_meta_boxes', array( 'MX_Cogify_Post_Metabox', 'register' ) );
            add_action( 'save_post', array( 'MX_Cogify_Post_Metabox', 'save' ) );
        }

        // Activation: generate llms.txt.
        register_activation_hook( MX_COGIFY_PLUGIN_FILE, array( $this, 'activate' ) );
        register_deactivation_hook( MX_COGIFY_PLUGIN_FILE, array( $this, 'deactivate' ) );

        // Rewrite rules for llms.txt and .well-known/mx-cogs.json.
        add_action( 'init', array( 'MX_Cogify_Llms_Txt', 'register_rewrite' ) );
        add_action( 'template_redirect', array( 'MX_Cogify_Llms_Txt', 'serve' ) );
        add_action( 'init', array( 'MX_Cogify_Manifest_Server', 'register_rewrite' ) );
        add_action( 'template_redirect', array( 'MX_Cogify_Manifest_Server', 'serve' ) );

        // Regenerate manifest when content changes.
        add_action( 'save_post', array( 'MX_Cogify_Manifest_Server', 'on_post_save' ), 20, 2 );
    }

    /**
     * Inject meta tags into wp_head.
     */
    public function inject_meta_tags() {
        if ( is_admin() || wp_doing_ajax() ) {
            return;
        }

        $resolver = new MX_Cogify_Conflict_Resolver();
        $options  = get_option( 'mx_cogify_settings', array() );
        $post     = get_queried_object();

        // Check if this post is excluded.
        if ( $post instanceof WP_Post ) {
            $excluded = get_post_meta( $post->ID, '_mx_cogify_exclude', true );
            if ( $excluded ) {
                return;
            }
        }

        echo "\n<!-- MX Cogify v" . esc_attr( MX_COGIFY_VERSION ) . " -->\n";

        // Layer 1-3: Document fundamentals, Open Graph, Twitter Card.
        if ( ! $resolver->has_seo_plugin() ) {
            $injector = new MX_Cogify_Meta_Injector( $options, $post );
            echo $injector->render_fundamentals();
            echo $injector->render_open_graph();
            echo $injector->render_twitter_card();
        }

        // Layer 4: Discovery.
        echo '<link rel="llms-txt" href="/llms.txt">' . "\n";

        // Layer 5: MX Carrier Tags (always injected).
        $mx_tags = new MX_Cogify_MX_Tags( $options, $post );
        echo $mx_tags->render();

        // Layer 6: Schema.org JSON-LD.
        if ( ! $resolver->has_schema_output() ) {
            $schema = new MX_Cogify_Schema_Generator( $options, $post );
            echo $schema->render();
        }

        echo "<!-- /MX Cogify -->\n";
    }

    /**
     * Plugin activation.
     */
    public function activate() {
        MX_Cogify_Llms_Txt::generate();

        // Generate the .well-known/mx-cogs.json manifest.
        $client = new MX_Cogify_Reginald_Client();
        $client->generate_manifest();

        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation.
     */
    public function deactivate() {
        flush_rewrite_rules();
    }
}

// Boot the plugin.
MX_Cogify::instance();
