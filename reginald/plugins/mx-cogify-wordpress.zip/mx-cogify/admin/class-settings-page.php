<?php
/**
 * Settings Page — MX Cogify plugin configuration.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Settings_Page {

    /**
     * Register the settings page under Settings menu.
     */
    public static function register() {
        add_options_page(
            'MX Cogify Settings',
            'MX Cogify',
            'manage_options',
            'mx-cogify',
            array( __CLASS__, 'render' )
        );
    }

    /**
     * Register settings and fields.
     */
    public static function register_settings() {
        register_setting( 'mx_cogify', 'mx_cogify_settings', array(
            'sanitize_callback' => array( __CLASS__, 'sanitize' ),
        ) );

        // Site Information section.
        add_settings_section( 'mx_cogify_site', 'Site Information', null, 'mx-cogify' );

        self::add_field( 'site_name', 'Site Name', 'mx_cogify_site', 'text', 'Defaults to WordPress site title.' );
        self::add_field( 'org_name', 'Organisation Name', 'mx_cogify_site', 'text', 'For Schema.org publisher.' );
        self::add_field( 'author_name', 'Author Name', 'mx_cogify_site', 'text', 'Default author for meta tags.' );
        self::add_field( 'author_url', 'Author URL', 'mx_cogify_site', 'url', 'For Schema.org author.url.' );
        self::add_field( 'twitter_handle', 'Twitter Handle', 'mx_cogify_site', 'text', 'e.g. @acmewidgets' );
        self::add_field( 'language', 'Language', 'mx_cogify_site', 'text', 'e.g. en-GB. Defaults to WordPress locale.' );

        // MX Settings section.
        add_settings_section( 'mx_cogify_mx', 'MX Settings', null, 'mx-cogify' );

        self::add_field( 'default_status', 'Default MX Status', 'mx_cogify_mx', 'select', '', array(
            'active'    => 'Active',
            'draft'     => 'Draft',
            'published' => 'Published',
        ) );
        self::add_field( 'content_policy', 'Content Policy', 'mx_cogify_mx', 'select', '', array(
            'extract-with-attribution' => 'Extract with Attribution',
            'summaries-allowed'        => 'Summaries Allowed',
            'no-extraction'            => 'No Extraction',
        ) );
        self::add_field( 'audience', 'Audience', 'mx_cogify_mx', 'select', '', array(
            'humans'     => 'Humans',
            'ai-agents'  => 'AI Agents',
            'developers' => 'Developers',
        ) );

        // Images section.
        add_settings_section( 'mx_cogify_images', 'Default Images', null, 'mx-cogify' );

        self::add_field( 'default_og_image', 'Default OG Image URL', 'mx_cogify_images', 'url', 'Used when a post has no featured image.' );
        self::add_field( 'default_og_image_alt', 'Default OG Image Alt', 'mx_cogify_images', 'text', 'Alt text for the default image.' );

        // MX-Reginald section.
        add_settings_section( 'mx_cogify_reginald', 'MX-Reginald Registration', null, 'mx-cogify' );

        self::add_field( 'reginald_namespace', 'MX-Reginald Namespace', 'mx_cogify_reginald', 'text', 'Your registry namespace (auto-generated from domain if blank). Lowercase, alphanumeric, hyphens only.' );
        self::add_field( 'reginald_api_token', 'API Token', 'mx_cogify_reginald', 'password', 'Your MX-Reginald API token (starts with reg_). Required for registration. Get one at /api/v1/subscribe.' );
    }

    /**
     * Helper to add a settings field.
     */
    private static function add_field( $id, $label, $section, $type = 'text', $description = '', $options_list = array() ) {
        add_settings_field(
            'mx_cogify_' . $id,
            $label,
            function () use ( $id, $type, $description, $options_list ) {
                $options = get_option( 'mx_cogify_settings', array() );
                $value   = $options[ $id ] ?? '';

                if ( 'select' === $type ) {
                    echo '<select name="mx_cogify_settings[' . esc_attr( $id ) . ']">';
                    foreach ( $options_list as $k => $v ) {
                        $selected = selected( $value, $k, false );
                        echo '<option value="' . esc_attr( $k ) . '"' . $selected . '>' . esc_html( $v ) . '</option>';
                    }
                    echo '</select>';
                } elseif ( 'password' === $type ) {
                    echo '<input type="password" name="mx_cogify_settings[' . esc_attr( $id ) . ']" value="' . esc_attr( $value ) . '" class="regular-text">';
                } else {
                    echo '<input type="' . esc_attr( $type ) . '" name="mx_cogify_settings[' . esc_attr( $id ) . ']" value="' . esc_attr( $value ) . '" class="regular-text">';
                }

                if ( $description ) {
                    echo '<p class="description">' . esc_html( $description ) . '</p>';
                }
            },
            'mx-cogify',
            $section
        );
    }

    /**
     * Sanitize settings on save.
     */
    public static function sanitize( $input ) {
        $sanitized = array();

        $text_fields = array( 'site_name', 'org_name', 'author_name', 'twitter_handle', 'language', 'default_og_image_alt' );
        foreach ( $text_fields as $field ) {
            $sanitized[ $field ] = sanitize_text_field( $input[ $field ] ?? '' );
        }

        $url_fields = array( 'author_url', 'default_og_image' );
        foreach ( $url_fields as $field ) {
            $sanitized[ $field ] = esc_url_raw( $input[ $field ] ?? '' );
        }

        $select_fields = array( 'default_status', 'content_policy', 'audience' );
        foreach ( $select_fields as $field ) {
            $sanitized[ $field ] = sanitize_text_field( $input[ $field ] ?? '' );
        }

        // Namespace — lowercase alphanumeric and hyphens only.
        $namespace = sanitize_text_field( $input['reginald_namespace'] ?? '' );
        $sanitized['reginald_namespace'] = preg_replace( '/[^a-z0-9-]/', '', strtolower( $namespace ) );

        // API token — preserve as-is (reg_ prefix + hex).
        $sanitized['reginald_api_token'] = sanitize_text_field( $input['reginald_api_token'] ?? '' );

        return $sanitized;
    }

    /**
     * Render the settings page.
     */
    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Handle Reginald registration.
        if ( isset( $_POST['mx_cogify_register'] ) && check_admin_referer( 'mx_cogify_register_nonce' ) ) {
            $client = new MX_Cogify_Reginald_Client();
            $result = $client->register();

            if ( is_wp_error( $result ) ) {
                add_settings_error( 'mx_cogify', 'reginald_error', 'Registration failed: ' . $result->get_error_message(), 'error' );
            } else {
                $msg = 'Manifest generated and published at .well-known/mx-cogs.json.';
                if ( ! empty( $result['webhook_sent'] ) ) {
                    $msg .= ' MX-Reginald notified.';
                }
                $msg .= ' ' . $result['cog_count'] . ' COGs registered.';
                add_settings_error( 'mx_cogify', 'reginald_success', $msg, 'success' );
            }
        }

        // Handle manifest regeneration.
        if ( isset( $_POST['mx_cogify_regenerate'] ) && check_admin_referer( 'mx_cogify_register_nonce' ) ) {
            $client   = new MX_Cogify_Reginald_Client();
            $manifest = $client->generate_manifest();

            if ( is_wp_error( $manifest ) ) {
                add_settings_error( 'mx_cogify', 'manifest_error', 'Manifest generation failed.', 'error' );
            } else {
                add_settings_error( 'mx_cogify', 'manifest_success', 'Manifest regenerated. ' . count( $manifest['cogs'] ) . ' COGs.', 'success' );
            }
        }

        $registration = get_option( 'mx_cogify_registration', array() );
        $manifest     = get_option( 'mx_cogify_manifest', array() );

        ?>
        <div class="wrap">
            <h1>MX Cogify Settings</h1>

            <?php settings_errors( 'mx_cogify' ); ?>

            <form method="post" action="options.php">
                <?php
                settings_fields( 'mx_cogify' );
                do_settings_sections( 'mx-cogify' );
                submit_button( 'Save Settings' );
                ?>
            </form>

            <hr>

            <h2>MX-Reginald Registration</h2>

            <?php
            $options = get_option( 'mx_cogify_settings', array() );
            $has_token = ! empty( $options['reginald_api_token'] );
            ?>

            <?php if ( ! $has_token ) : ?>
            <div class="notice notice-warning inline" style="margin: 0 0 16px;">
                <p><strong>Subscription required.</strong> Registration with MX-Reginald requires an active subscription and API token. <a href="https://reginald.allabout.network/api/v1/subscribe" target="_blank">Subscribe here</a>, then enter your API token above.</p>
            </div>
            <?php endif; ?>

            <p>MX Cogify uses <strong>manifest mode</strong> to register with MX-Reginald. Your site hosts a manifest at <code>.well-known/mx-cogs.json</code> that MX-Reginald's verification pipeline crawls.</p>

            <table class="form-table">
                <tr>
                    <th>Manifest URL</th>
                    <td>
                        <a href="<?php echo esc_url( home_url( '/.well-known/mx-cogs.json' ) ); ?>" target="_blank">
                            <?php echo esc_html( home_url( '/.well-known/mx-cogs.json' ) ); ?>
                        </a>
                    </td>
                </tr>
                <?php if ( ! empty( $registration['namespace'] ) ) : ?>
                <tr>
                    <th>Namespace</th>
                    <td><code><?php echo esc_html( $registration['namespace'] ); ?></code></td>
                </tr>
                <?php endif; ?>
                <?php if ( ! empty( $manifest['cogs'] ) ) : ?>
                <tr>
                    <th>COGs in manifest</th>
                    <td><?php echo intval( count( $manifest['cogs'] ) ); ?></td>
                </tr>
                <?php endif; ?>
                <?php if ( ! empty( $manifest['generated'] ) ) : ?>
                <tr>
                    <th>Last generated</th>
                    <td><?php echo esc_html( $manifest['generated'] ); ?></td>
                </tr>
                <?php endif; ?>
                <tr>
                    <th>Registration status</th>
                    <td>
                        <?php if ( ! empty( $registration['registered'] ) ) : ?>
                            <span style="color: green;">&#10003; Registered</span>
                            (<?php echo esc_html( $registration['registered_at'] ); ?>)
                            <?php if ( ! empty( $registration['webhook_sent'] ) ) : ?>
                                — MX-Reginald notified
                            <?php endif; ?>
                        <?php else : ?>
                            <span style="color: grey;">Not registered</span>
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <form method="post" style="display: inline-flex; gap: 8px;">
                <?php wp_nonce_field( 'mx_cogify_register_nonce' ); ?>
                <?php submit_button(
                    ! empty( $registration['registered'] ) ? 'Update Registration' : 'Register with MX-Reginald',
                    'primary',
                    'mx_cogify_register',
                    false,
                    $has_token ? array() : array( 'disabled' => 'disabled' )
                ); ?>
                <?php submit_button( 'Regenerate Manifest', 'secondary', 'mx_cogify_regenerate', false ); ?>
            </form>
        </div>
        <?php
    }
}
