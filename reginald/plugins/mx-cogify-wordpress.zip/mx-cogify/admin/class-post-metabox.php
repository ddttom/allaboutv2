<?php
/**
 * Post Metabox — per-post MX settings in the editor.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Post_Metabox {

    /**
     * Register the metabox for posts and pages.
     */
    public static function register() {
        $post_types = array( 'post', 'page' );

        // Add product if WooCommerce is active.
        if ( post_type_exists( 'product' ) ) {
            $post_types[] = 'product';
        }

        add_meta_box(
            'mx_cogify_metabox',
            'MX Cogify',
            array( __CLASS__, 'render' ),
            $post_types,
            'side',
            'default'
        );
    }

    /**
     * Render the metabox.
     */
    public static function render( $post ) {
        wp_nonce_field( 'mx_cogify_metabox', 'mx_cogify_metabox_nonce' );

        $content_type = get_post_meta( $post->ID, '_mx_cogify_content_type', true );
        $tags         = get_post_meta( $post->ID, '_mx_cogify_tags', true );
        $status       = get_post_meta( $post->ID, '_mx_cogify_status', true );
        $schema_type  = get_post_meta( $post->ID, '_mx_cogify_schema_type', true );
        $exclude      = get_post_meta( $post->ID, '_mx_cogify_exclude', true );

        $auto_type   = MX_Cogify_MX_Tags::map_post_type( $post->post_type );
        $auto_tags   = self::get_auto_tags( $post );

        ?>
        <p>
            <label for="mx_cogify_content_type"><strong>MX Content Type</strong></label><br>
            <select name="mx_cogify_content_type" id="mx_cogify_content_type" style="width:100%">
                <option value="">Auto (<?php echo esc_html( $auto_type ); ?>)</option>
                <option value="blog-post" <?php selected( $content_type, 'blog-post' ); ?>>Blog Post</option>
                <option value="article" <?php selected( $content_type, 'article' ); ?>>Article</option>
                <option value="guide" <?php selected( $content_type, 'guide' ); ?>>Guide</option>
                <option value="product" <?php selected( $content_type, 'product' ); ?>>Product</option>
                <option value="landing-page" <?php selected( $content_type, 'landing-page' ); ?>>Landing Page</option>
                <option value="reference" <?php selected( $content_type, 'reference' ); ?>>Reference</option>
                <option value="document" <?php selected( $content_type, 'document' ); ?>>Document</option>
            </select>
        </p>

        <p>
            <label for="mx_cogify_tags"><strong>MX Tags</strong></label><br>
            <input type="text" name="mx_cogify_tags" id="mx_cogify_tags" value="<?php echo esc_attr( $tags ); ?>" style="width:100%" placeholder="<?php echo esc_attr( $auto_tags ); ?>">
            <span class="description">Comma-separated. Leave empty for auto-detection.</span>
        </p>

        <p>
            <label for="mx_cogify_status"><strong>MX Status Override</strong></label><br>
            <select name="mx_cogify_status" id="mx_cogify_status" style="width:100%">
                <option value="">Auto (from post status)</option>
                <option value="active" <?php selected( $status, 'active' ); ?>>Active</option>
                <option value="draft" <?php selected( $status, 'draft' ); ?>>Draft</option>
                <option value="published" <?php selected( $status, 'published' ); ?>>Published</option>
                <option value="deprecated" <?php selected( $status, 'deprecated' ); ?>>Deprecated</option>
            </select>
        </p>

        <p>
            <label for="mx_cogify_schema_type"><strong>Schema.org Type Override</strong></label><br>
            <select name="mx_cogify_schema_type" id="mx_cogify_schema_type" style="width:100%">
                <option value="">Auto</option>
                <option value="BlogPosting" <?php selected( $schema_type, 'BlogPosting' ); ?>>BlogPosting</option>
                <option value="TechArticle" <?php selected( $schema_type, 'TechArticle' ); ?>>TechArticle</option>
                <option value="WebPage" <?php selected( $schema_type, 'WebPage' ); ?>>WebPage</option>
                <option value="AboutPage" <?php selected( $schema_type, 'AboutPage' ); ?>>AboutPage</option>
                <option value="ContactPage" <?php selected( $schema_type, 'ContactPage' ); ?>>ContactPage</option>
                <option value="FAQPage" <?php selected( $schema_type, 'FAQPage' ); ?>>FAQPage</option>
                <option value="Product" <?php selected( $schema_type, 'Product' ); ?>>Product</option>
                <option value="Event" <?php selected( $schema_type, 'Event' ); ?>>Event</option>
            </select>
        </p>

        <p>
            <label>
                <input type="checkbox" name="mx_cogify_exclude" value="1" <?php checked( $exclude, '1' ); ?>>
                <strong>Exclude from MX</strong> — do not inject metadata on this page
            </label>
        </p>
        <?php
    }

    /**
     * Save metabox data.
     */
    public static function save( $post_id ) {
        if ( ! isset( $_POST['mx_cogify_metabox_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['mx_cogify_metabox_nonce'], 'mx_cogify_metabox' ) ) {
            return;
        }
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $fields = array( 'content_type', 'tags', 'status', 'schema_type' );
        foreach ( $fields as $field ) {
            $key   = '_mx_cogify_' . $field;
            $value = sanitize_text_field( $_POST[ 'mx_cogify_' . $field ] ?? '' );

            if ( $value ) {
                update_post_meta( $post_id, $key, $value );
            } else {
                delete_post_meta( $post_id, $key );
            }
        }

        // Exclude checkbox.
        if ( isset( $_POST['mx_cogify_exclude'] ) ) {
            update_post_meta( $post_id, '_mx_cogify_exclude', '1' );
        } else {
            delete_post_meta( $post_id, '_mx_cogify_exclude' );
        }
    }

    /**
     * Generate auto-detected tags from post categories and tags.
     */
    private static function get_auto_tags( $post ) {
        $terms = array();

        $categories = get_the_category( $post->ID );
        if ( $categories ) {
            foreach ( $categories as $cat ) {
                if ( 'uncategorized' !== $cat->slug ) {
                    $terms[] = $cat->slug;
                }
            }
        }

        $post_tags = get_the_tags( $post->ID );
        if ( $post_tags ) {
            foreach ( $post_tags as $tag ) {
                $terms[] = $tag->slug;
            }
        }

        return implode( ', ', array_unique( $terms ) );
    }
}
