=== MX Cogify ===
Contributors: tomcranstoun
Tags: seo, schema, structured-data, ai, machine-experience, metadata
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Cogify your WordPress site. Add MX metadata, Schema.org structured data, and Open Graph tags. Register with Reginald.

== Description ==

MX Cogify makes your WordPress site readable by AI agents. It adds the complete MX meta tag stack to every page:

* **MX carrier tags** — machine-readable governance metadata (status, content type, content policy)
* **Schema.org JSON-LD** — structured data for blog posts, pages, products, and more
* **Open Graph + Twitter Card** — social sharing metadata with image alt text
* **llms.txt** — structured site description for AI agent discovery

One button registers your site with Reginald, the global cog registry, making your content discoverable by AI agents worldwide.

= What is MX? =

Machine Experience (MX) is the practice of making internet content readable by every machine on earth. When AI agents visit your website, they should not have to guess what they are looking at. MX metadata makes your content explicit, structured, and unambiguous.

= Works with existing SEO plugins =

MX Cogify detects Yoast SEO, RankMath, and All in One SEO. When present, it defers on meta descriptions, Open Graph, and Twitter Card tags, adding only the MX-specific layers that no other plugin provides.

= WooCommerce compatible =

Products automatically get Schema.org Product markup with offers, pricing, and availability.

== Installation ==

1. Upload the `mx-cogify` folder to `/wp-content/plugins/`
2. Activate the plugin through the Plugins menu
3. Go to Settings > MX Cogify to configure your site information
4. (Optional) Click "Register with Reginald" to publish your site to the global registry

== Frequently Asked Questions ==

= Do I need a Reginald account? =

No. The plugin works without registration. Reginald registration makes your site discoverable in the global cog registry but is entirely optional.

= Does this replace Yoast? =

MX Cogify can work alongside Yoast or replace its Schema.org and meta tag output. When Yoast is detected, MX Cogify only adds what Yoast does not: MX carrier tags and enhanced Schema.org types.

= Is it free? =

Yes. The plugin is free forever. Revenue comes from optional Reginald listing fees, not the plugin.

== Changelog ==

= 0.1.0 =
* Initial release
* Full MX meta tag stack (7 layers)
* Schema.org JSON-LD generation
* SEO plugin conflict detection
* Reginald registration
* llms.txt generation
* Per-post metabox overrides
