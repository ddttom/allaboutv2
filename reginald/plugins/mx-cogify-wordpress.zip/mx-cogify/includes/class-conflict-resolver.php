<?php
/**
 * Conflict Resolver — detects existing SEO plugins and Schema.org output.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Conflict_Resolver {

    /**
     * Known SEO plugins that handle meta tags, OG, and Twitter Card.
     *
     * @var array
     */
    private static $seo_plugins = array(
        'wordpress-seo/wp-seo.php',           // Yoast SEO
        'seo-by-rank-math/rank-math.php',     // RankMath
        'all-in-one-seo-pack/all_in_one_seo_pack.php', // AIOSEO
        'autodescription/autodescription.php', // The SEO Framework
    );

    /**
     * Check if an SEO plugin is active.
     *
     * @return bool
     */
    public function has_seo_plugin() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        foreach ( self::$seo_plugins as $plugin ) {
            if ( is_plugin_active( $plugin ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if Schema.org JSON-LD is already being output.
     * Called during wp_head to detect existing structured data.
     *
     * @return bool
     */
    public function has_schema_output() {
        // Yoast and RankMath both output Schema by default.
        // Check if their Schema features are enabled.
        if ( $this->has_seo_plugin() ) {
            // Yoast: check if Schema is enabled.
            $yoast_schema = get_option( 'wpseo_titles' );
            if ( is_array( $yoast_schema ) ) {
                return true;
            }

            // RankMath: check Schema module.
            if ( class_exists( 'RankMath' ) ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get the name of the active SEO plugin (for admin display).
     *
     * @return string|null
     */
    public function get_active_seo_plugin_name() {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $names = array(
            'wordpress-seo/wp-seo.php'           => 'Yoast SEO',
            'seo-by-rank-math/rank-math.php'     => 'RankMath',
            'all-in-one-seo-pack/all_in_one_seo_pack.php' => 'All in One SEO',
            'autodescription/autodescription.php' => 'The SEO Framework',
        );

        foreach ( $names as $plugin => $name ) {
            if ( is_plugin_active( $plugin ) ) {
                return $name;
            }
        }

        return null;
    }
}
