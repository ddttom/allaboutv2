<?php
/**
 * Manifest Server — serves .well-known/mx-cogs.json for MX-Reginald discovery.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Manifest_Server {

    /**
     * Register rewrite rules for .well-known/mx-cogs.json.
     */
    public static function register_rewrite() {
        add_rewrite_rule(
            '^\.well-known/mx-cogs\.json$',
            'index.php?mx_cogs_manifest=1',
            'top'
        );

        add_filter( 'query_vars', function ( $vars ) {
            $vars[] = 'mx_cogs_manifest';
            return $vars;
        } );
    }

    /**
     * Serve the manifest when requested.
     */
    public static function serve() {
        if ( ! get_query_var( 'mx_cogs_manifest' ) ) {
            return;
        }

        $manifest = get_option( 'mx_cogify_manifest', null );

        if ( ! $manifest ) {
            // Generate on first request if not yet created.
            $client   = new MX_Cogify_Reginald_Client();
            $manifest = $client->generate_manifest();
        }

        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Access-Control-Allow-Origin: *' );
        header( 'Cache-Control: public, max-age=3600' );

        echo wp_json_encode( $manifest, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
        exit;
    }

    /**
     * Regenerate manifest when posts are published or updated.
     *
     * @param int     $post_id Post ID.
     * @param WP_Post $post    Post object.
     */
    public static function on_post_save( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( wp_is_post_revision( $post_id ) ) {
            return;
        }

        // Only regenerate for public post types.
        if ( ! in_array( $post->post_type, array( 'post', 'page', 'product' ), true ) ) {
            return;
        }

        // Debounce: don't regenerate more than once per minute.
        $last_gen = get_transient( 'mx_cogify_manifest_gen' );
        if ( $last_gen ) {
            return;
        }

        set_transient( 'mx_cogify_manifest_gen', true, 60 );

        $client = new MX_Cogify_Reginald_Client();
        $client->generate_manifest();
    }
}
