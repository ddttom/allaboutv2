<?php
/**
 * Meta Injector — generates Layers 1-3 (fundamentals, Open Graph, Twitter Card).
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Meta_Injector {

    private $options;
    private $post;

    public function __construct( $options, $post ) {
        $this->options = $options;
        $this->post    = $post;
    }

    /**
     * Layer 1: Document fundamentals.
     */
    public function render_fundamentals() {
        $output = '';
        $desc   = $this->get_description();
        $author = $this->get_author();
        $url    = $this->get_canonical_url();

        if ( $desc ) {
            $output .= '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
        }
        if ( $author ) {
            $output .= '<meta name="author" content="' . esc_attr( $author ) . '">' . "\n";
        }
        if ( $url ) {
            $output .= '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
        }

        return $output;
    }

    /**
     * Layer 2: Open Graph tags.
     */
    public function render_open_graph() {
        $output = '';
        $desc   = $this->get_description();
        $url    = $this->get_canonical_url();
        $title  = $this->get_title();
        $image  = $this->get_og_image();
        $type   = $this->get_og_type();

        $output .= '<meta property="og:type" content="' . esc_attr( $type ) . '">' . "\n";
        $output .= '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
        $output .= '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";

        if ( $desc ) {
            $output .= '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
        }

        if ( $image ) {
            $output .= '<meta property="og:image" content="' . esc_url( $image['url'] ) . '">' . "\n";
            if ( ! empty( $image['alt'] ) ) {
                $output .= '<meta property="og:image:alt" content="' . esc_attr( $image['alt'] ) . '">' . "\n";
            }
            if ( ! empty( $image['width'] ) ) {
                $output .= '<meta property="og:image:width" content="' . intval( $image['width'] ) . '">' . "\n";
            }
            if ( ! empty( $image['height'] ) ) {
                $output .= '<meta property="og:image:height" content="' . intval( $image['height'] ) . '">' . "\n";
            }
        }

        $site_name = $this->options['site_name'] ?? get_bloginfo( 'name' );
        $locale    = $this->options['language'] ?? get_locale();

        $output .= '<meta property="og:site_name" content="' . esc_attr( $site_name ) . '">' . "\n";
        $output .= '<meta property="og:locale" content="' . esc_attr( str_replace( '-', '_', $locale ) ) . '">' . "\n";

        // Article-specific tags.
        if ( 'article' === $type && $this->post instanceof WP_Post ) {
            $output .= '<meta property="article:published_time" content="' . esc_attr( get_the_date( 'Y-m-d', $this->post ) ) . '">' . "\n";
            $output .= '<meta property="article:modified_time" content="' . esc_attr( get_the_modified_date( 'Y-m-d', $this->post ) ) . '">' . "\n";
            $output .= '<meta property="article:author" content="' . esc_attr( $this->get_author() ) . '">' . "\n";
        }

        return $output;
    }

    /**
     * Layer 3: Twitter Card tags.
     */
    public function render_twitter_card() {
        $output = '';
        $desc   = $this->get_description();
        $title  = $this->get_title();
        $image  = $this->get_og_image();

        $output .= '<meta name="twitter:card" content="summary_large_image">' . "\n";
        $output .= '<meta name="twitter:title" content="' . esc_attr( $title ) . '">' . "\n";

        if ( $desc ) {
            $output .= '<meta name="twitter:description" content="' . esc_attr( $desc ) . '">' . "\n";
        }

        if ( $image ) {
            $output .= '<meta name="twitter:image" content="' . esc_url( $image['url'] ) . '">' . "\n";
            if ( ! empty( $image['alt'] ) ) {
                $output .= '<meta name="twitter:image:alt" content="' . esc_attr( $image['alt'] ) . '">' . "\n";
            }
        }

        $twitter = $this->options['twitter_handle'] ?? '';
        if ( $twitter ) {
            $output .= '<meta name="twitter:site" content="' . esc_attr( $twitter ) . '">' . "\n";
        }

        return $output;
    }

    // --- Private helpers ---

    private function get_title() {
        if ( $this->post instanceof WP_Post ) {
            return get_the_title( $this->post );
        }
        return get_bloginfo( 'name' );
    }

    private function get_description() {
        if ( $this->post instanceof WP_Post ) {
            // Use excerpt if available, otherwise truncate content.
            $excerpt = get_the_excerpt( $this->post );
            if ( $excerpt ) {
                return wp_trim_words( $excerpt, 25, '...' );
            }
            return wp_trim_words( wp_strip_all_tags( $this->post->post_content ), 25, '...' );
        }
        return get_bloginfo( 'description' );
    }

    private function get_author() {
        if ( $this->post instanceof WP_Post ) {
            return get_the_author_meta( 'display_name', $this->post->post_author );
        }
        return $this->options['author_name'] ?? '';
    }

    private function get_canonical_url() {
        if ( $this->post instanceof WP_Post ) {
            return get_permalink( $this->post );
        }
        return home_url( $_SERVER['REQUEST_URI'] ?? '/' );
    }

    private function get_og_type() {
        if ( $this->post instanceof WP_Post ) {
            if ( 'post' === $this->post->post_type ) {
                return 'article';
            }
            if ( 'product' === $this->post->post_type ) {
                return 'product';
            }
        }
        return 'website';
    }

    private function get_og_image() {
        // Try featured image first.
        if ( $this->post instanceof WP_Post && has_post_thumbnail( $this->post ) ) {
            $thumb_id  = get_post_thumbnail_id( $this->post );
            $image_src = wp_get_attachment_image_src( $thumb_id, 'large' );
            $alt       = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );

            if ( $image_src ) {
                return array(
                    'url'    => $image_src[0],
                    'width'  => $image_src[1],
                    'height' => $image_src[2],
                    'alt'    => $alt ?: $this->get_title(),
                );
            }
        }

        // Fall back to site default.
        $default_image = $this->options['default_og_image'] ?? '';
        if ( $default_image ) {
            return array(
                'url'    => $default_image,
                'width'  => '',
                'height' => '',
                'alt'    => $this->options['default_og_image_alt'] ?? get_bloginfo( 'name' ),
            );
        }

        return null;
    }
}
