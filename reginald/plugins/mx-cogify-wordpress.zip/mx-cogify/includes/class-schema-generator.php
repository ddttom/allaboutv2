<?php
/**
 * Schema Generator — generates Layer 6 Schema.org JSON-LD.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Schema_Generator {

    private $options;
    private $post;

    public function __construct( $options, $post ) {
        $this->options = $options;
        $this->post    = $post;
    }

    /**
     * Render Schema.org JSON-LD block.
     */
    public function render() {
        $schema = $this->build_schema();
        if ( ! $schema ) {
            return '';
        }

        $json = wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );

        return '<script type="application/ld+json">' . "\n" . $json . "\n" . '</script>' . "\n";
    }

    /**
     * Build the Schema.org data structure.
     */
    private function build_schema() {
        if ( ! $this->post instanceof WP_Post ) {
            return $this->build_website_schema();
        }

        $type = $this->get_schema_type();

        switch ( $type ) {
            case 'BlogPosting':
            case 'TechArticle':
                return $this->build_article_schema( $type );
            case 'Product':
                return $this->build_product_schema();
            default:
                return $this->build_webpage_schema();
        }
    }

    /**
     * Build article/blog post schema.
     */
    private function build_article_schema( $type = 'BlogPosting' ) {
        return array(
            '@context'      => 'https://schema.org',
            '@type'         => $type,
            'headline'      => get_the_title( $this->post ),
            'description'   => wp_trim_words( get_the_excerpt( $this->post ), 25 ),
            'author'        => $this->get_author_schema(),
            'datePublished' => get_the_date( 'Y-m-d', $this->post ),
            'dateModified'  => get_the_modified_date( 'Y-m-d', $this->post ),
            'inLanguage'    => $this->options['language'] ?? get_bloginfo( 'language' ),
            'url'           => get_permalink( $this->post ),
            'publisher'     => $this->get_publisher_schema(),
        );
    }

    /**
     * Build product schema (WooCommerce).
     */
    private function build_product_schema() {
        $schema = array(
            '@context'    => 'https://schema.org',
            '@type'       => 'Product',
            'name'        => get_the_title( $this->post ),
            'description' => wp_trim_words( get_the_excerpt( $this->post ), 25 ),
            'url'         => get_permalink( $this->post ),
        );

        // Add image if available.
        if ( has_post_thumbnail( $this->post ) ) {
            $schema['image'] = get_the_post_thumbnail_url( $this->post, 'large' );
        }

        // Add WooCommerce price data if available.
        if ( function_exists( 'wc_get_product' ) ) {
            $product = wc_get_product( $this->post->ID );
            if ( $product ) {
                $schema['offers'] = array(
                    '@type'         => 'Offer',
                    'price'         => $product->get_price(),
                    'priceCurrency' => get_woocommerce_currency(),
                    'availability'  => $product->is_in_stock()
                        ? 'https://schema.org/InStock'
                        : 'https://schema.org/OutOfStock',
                );
            }
        }

        return $schema;
    }

    /**
     * Build generic web page schema.
     */
    private function build_webpage_schema() {
        return array(
            '@context'      => 'https://schema.org',
            '@type'         => 'WebPage',
            'name'          => get_the_title( $this->post ),
            'description'   => wp_trim_words( get_the_excerpt( $this->post ), 25 ),
            'url'           => get_permalink( $this->post ),
            'inLanguage'    => $this->options['language'] ?? get_bloginfo( 'language' ),
            'dateModified'  => get_the_modified_date( 'Y-m-d', $this->post ),
            'publisher'     => $this->get_publisher_schema(),
        );
    }

    /**
     * Build website schema (for non-singular pages).
     */
    private function build_website_schema() {
        return array(
            '@context' => 'https://schema.org',
            '@type'    => 'WebSite',
            'name'     => $this->options['site_name'] ?? get_bloginfo( 'name' ),
            'url'      => home_url( '/' ),
            'publisher' => $this->get_publisher_schema(),
        );
    }

    /**
     * Get author structured data.
     */
    private function get_author_schema() {
        $name = '';
        $url  = '';

        if ( $this->post instanceof WP_Post ) {
            $name = get_the_author_meta( 'display_name', $this->post->post_author );
            $url  = get_the_author_meta( 'url', $this->post->post_author );
        }

        if ( ! $name ) {
            $name = $this->options['author_name'] ?? '';
        }
        if ( ! $url ) {
            $url = $this->options['author_url'] ?? '';
        }

        $schema = array(
            '@type' => 'Person',
            'name'  => $name,
        );

        if ( $url ) {
            $schema['url'] = $url;
        }

        return $schema;
    }

    /**
     * Get publisher structured data.
     */
    private function get_publisher_schema() {
        return array(
            '@type' => 'Organization',
            'name'  => $this->options['org_name'] ?? get_bloginfo( 'name' ),
        );
    }

    /**
     * Determine the Schema.org type for this post.
     */
    private function get_schema_type() {
        // Per-post override.
        $override = get_post_meta( $this->post->ID, '_mx_cogify_schema_type', true );
        if ( $override ) {
            return $override;
        }

        // Auto-detect from post type.
        $map = array(
            'post'    => 'BlogPosting',
            'page'    => 'WebPage',
            'product' => 'Product',
        );

        return $map[ $this->post->post_type ] ?? 'WebPage';
    }
}
