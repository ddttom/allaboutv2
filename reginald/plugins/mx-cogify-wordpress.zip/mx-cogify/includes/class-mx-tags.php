<?php
/**
 * MX Tags — generates Layer 5 MX carrier tags.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_MX_Tags {

    private $options;
    private $post;

    public function __construct( $options, $post ) {
        $this->options = $options;
        $this->post    = $post;
    }

    /**
     * Render MX carrier tags.
     */
    public function render() {
        $output = '';

        // mx:status — always present.
        $status = $this->get_status();
        $output .= '<meta name="mx:status" content="' . esc_attr( $status ) . '">' . "\n";

        // mx:contentType — always present.
        $content_type = $this->get_content_type();
        $output .= '<meta name="mx:contentType" content="' . esc_attr( $content_type ) . '">' . "\n";

        // mx:tags — optional, from categories/tags.
        $tags = $this->get_tags();
        if ( $tags ) {
            $output .= '<meta name="mx:tags" content="' . esc_attr( $tags ) . '">' . "\n";
        }

        // mx:content-policy — optional, from settings.
        $policy = $this->options['content_policy'] ?? '';
        if ( $policy ) {
            $output .= '<meta name="mx:content-policy" content="' . esc_attr( $policy ) . '">' . "\n";
        }

        // mx:audience — optional, from settings.
        $audience = $this->options['audience'] ?? '';
        if ( $audience ) {
            $output .= '<meta name="mx:audience" content="' . esc_attr( $audience ) . '">' . "\n";
        }

        return $output;
    }

    /**
     * Get MX status for this page.
     */
    private function get_status() {
        // Per-post override.
        if ( $this->post instanceof WP_Post ) {
            $override = get_post_meta( $this->post->ID, '_mx_cogify_status', true );
            if ( $override ) {
                return $override;
            }

            // Map WordPress post status.
            if ( 'publish' === $this->post->post_status ) {
                return 'published';
            }
            if ( 'draft' === $this->post->post_status ) {
                return 'draft';
            }
        }

        return $this->options['default_status'] ?? 'active';
    }

    /**
     * Get MX content type.
     */
    private function get_content_type() {
        // Per-post override.
        if ( $this->post instanceof WP_Post ) {
            $override = get_post_meta( $this->post->ID, '_mx_cogify_content_type', true );
            if ( $override ) {
                return $override;
            }

            // Auto-detect from post type.
            return self::map_post_type( $this->post->post_type );
        }

        return 'landing-page';
    }

    /**
     * Map WordPress post type to mx:contentType.
     */
    public static function map_post_type( $post_type ) {
        $map = array(
            'post'    => 'blog-post',
            'page'    => 'landing-page',
            'product' => 'product',
        );

        return $map[ $post_type ] ?? 'document';
    }

    /**
     * Get MX tags from WordPress categories and tags.
     */
    private function get_tags() {
        // Per-post override.
        if ( $this->post instanceof WP_Post ) {
            $override = get_post_meta( $this->post->ID, '_mx_cogify_tags', true );
            if ( $override ) {
                return $override;
            }

            $terms = array();

            // Get categories.
            $categories = get_the_category( $this->post->ID );
            if ( $categories ) {
                foreach ( $categories as $cat ) {
                    if ( 'uncategorized' !== $cat->slug ) {
                        $terms[] = $cat->slug;
                    }
                }
            }

            // Get tags.
            $post_tags = get_the_tags( $this->post->ID );
            if ( $post_tags ) {
                foreach ( $post_tags as $tag ) {
                    $terms[] = $tag->slug;
                }
            }

            // Deduplicate and format.
            $terms = array_unique( $terms );
            if ( ! empty( $terms ) ) {
                return implode( ', ', $terms );
            }
        }

        return '';
    }
}
