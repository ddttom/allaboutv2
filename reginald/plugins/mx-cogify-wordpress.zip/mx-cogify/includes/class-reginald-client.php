<?php
/**
 * MX-Reginald Client — manifest generation and registration for the MX-Reginald registry.
 *
 * MX-Reginald uses manifest mode: the publisher hosts .well-known/mx-cogs.json
 * on their own domain. MX-Reginald's verification pipeline crawls it.
 * This class generates the manifest and submits the registration webhook.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Reginald_Client {

    /**
     * MX-Reginald webhook endpoint for registration notifications.
     */
    private $webhook_url = 'https://reginald.allabout.network/api/v1/register';

    /**
     * MX-Reginald status endpoint.
     */
    private $status_url = 'https://reginald.allabout.network/api/v1/publisher/status';

    /**
     * Register site with MX-Reginald.
     *
     * Flow:
     * 1. Generate .well-known/mx-cogs.json manifest on this site
     * 2. Notify MX-Reginald webhook that manifest is available (with Bearer token)
     * 3. MX-Reginald verification pipeline crawls and validates
     * 4. Store registration state locally
     *
     * @return array|WP_Error Registration result.
     */
    public function register() {
        // Check for API token.
        $token = $this->get_api_token();
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', 'MX-Reginald API token is required. Enter your token in MX Cogify settings.' );
        }

        // Step 1: Generate the manifest.
        $manifest = $this->generate_manifest();
        if ( is_wp_error( $manifest ) ) {
            return $manifest;
        }

        // Step 2: Notify MX-Reginald with Bearer token.
        $manifest_url = home_url( '/.well-known/mx-cogs.json' );
        $options      = get_option( 'mx_cogify_settings', array() );
        $namespace    = $this->get_namespace();

        $body = array(
            'namespace'    => $namespace,
            'name'         => $options['org_name'] ?? get_bloginfo( 'name' ),
            'domain'       => wp_parse_url( home_url(), PHP_URL_HOST ),
            'manifest_url' => $manifest_url,
            'contact'      => get_option( 'admin_email' ),
            'plugin'       => 'mx-cogify',
            'version'      => MX_COGIFY_VERSION,
        );

        $response = wp_remote_post(
            $this->webhook_url,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 30,
            )
        );

        // Store registration state regardless of webhook result.
        // The manifest is now hosted — MX-Reginald can crawl it anytime.
        $registration = array(
            'registered'    => true,
            'namespace'     => $namespace,
            'manifest_url'  => $manifest_url,
            'domain'        => wp_parse_url( home_url(), PHP_URL_HOST ),
            'registered_at' => current_time( 'mysql' ),
            'cog_count'     => count( $manifest['cogs'] ),
            'webhook_sent'  => ! is_wp_error( $response ),
        );

        if ( ! is_wp_error( $response ) ) {
            $code = wp_remote_retrieve_response_code( $response );
            $data = json_decode( wp_remote_retrieve_body( $response ), true );
            $registration['webhook_status'] = $code;
            $registration['listing_url']    = $data['listing_url'] ?? '';
        } else {
            $registration['webhook_status'] = 0;
            $registration['webhook_error']  = $response->get_error_message();
        }

        update_option( 'mx_cogify_registration', $registration );

        return $registration;
    }

    /**
     * Generate the .well-known/mx-cogs.json manifest.
     *
     * Follows the MX-Reginald publisher manifest schema:
     * https://reginald.allabout.network/schemas/publisher-manifest.json
     *
     * @return array|WP_Error The manifest data or error.
     */
    public function generate_manifest() {
        $options   = get_option( 'mx_cogify_settings', array() );
        $namespace = $this->get_namespace();
        $domain    = wp_parse_url( home_url(), PHP_URL_HOST );

        // Build the cogs array from published content.
        $cogs = $this->build_cogs_list();

        $manifest = array(
            'manifest_version' => '1.0',
            'publisher'        => array(
                'namespace' => $namespace,
                'name'      => $options['org_name'] ?? get_bloginfo( 'name' ),
                'domain'    => $domain,
                'contact'   => get_option( 'admin_email' ),
            ),
            'cogs'             => $cogs,
            'manifest_hash'    => 'sha256:' . hash( 'sha256', wp_json_encode( $cogs ) ),
            'generated'        => gmdate( 'c' ),
        );

        // Store the manifest for serving via rewrite rule.
        update_option( 'mx_cogify_manifest', $manifest );

        return $manifest;
    }

    /**
     * Build the cogs list from published WordPress content.
     *
     * Each published post/page/product becomes a COG entry in the manifest.
     * The canonical_url points to the actual page on the publisher's site.
     *
     * @return array Array of COG entries.
     */
    private function build_cogs_list() {
        $cogs  = array();
        $types = array( 'post', 'page' );

        if ( post_type_exists( 'product' ) ) {
            $types[] = 'product';
        }

        $posts = get_posts( array(
            'post_type'      => $types,
            'post_status'    => 'publish',
            'posts_per_page' => 100, // Limit for manifest size.
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ) );

        foreach ( $posts as $post ) {
            $excluded = get_post_meta( $post->ID, '_mx_cogify_exclude', true );
            if ( $excluded ) {
                continue;
            }

            $content_type = get_post_meta( $post->ID, '_mx_cogify_content_type', true );
            if ( ! $content_type ) {
                $content_type = MX_Cogify_MX_Tags::map_post_type( $post->post_type );
            }

            $tags_str = get_post_meta( $post->ID, '_mx_cogify_tags', true );
            $tags     = array();
            if ( $tags_str ) {
                $tags = array_map( 'trim', explode( ',', $tags_str ) );
            } else {
                // Auto-generate from categories and tags.
                $categories = get_the_category( $post->ID );
                if ( $categories ) {
                    foreach ( $categories as $cat ) {
                        if ( 'uncategorized' !== $cat->slug ) {
                            $tags[] = $cat->slug;
                        }
                    }
                }
                $post_tags = get_the_tags( $post->ID );
                if ( $post_tags ) {
                    foreach ( $post_tags as $tag ) {
                        $tags[] = $tag->slug;
                    }
                }
            }

            $url     = get_permalink( $post );
            $content = $post->post_content;
            $hash    = 'sha256:' . hash( 'sha256', $content );

            $cogs[] = array(
                'name'          => $post->post_name,
                'version'       => '1.0.0',
                'description'   => wp_trim_words( get_the_excerpt( $post ), 20, '' ),
                'canonical_url' => $url,
                'content_hash'  => $hash,
                'category'      => $content_type,
                'tags'          => array_values( array_unique( $tags ) ),
                'type'          => 'info-doc',
                'modified'      => get_the_modified_date( 'Y-m-d', $post ),
            );
        }

        return $cogs;
    }

    /**
     * Get the MX-Reginald namespace for this site.
     * Derived from the domain name, sanitised to lowercase alphanumeric + hyphens.
     *
     * @return string Namespace identifier.
     */
    private function get_namespace() {
        $options = get_option( 'mx_cogify_settings', array() );

        // Allow manual override.
        if ( ! empty( $options['reginald_namespace'] ) ) {
            return $options['reginald_namespace'];
        }

        // Auto-generate from domain.
        $domain = wp_parse_url( home_url(), PHP_URL_HOST );
        $namespace = preg_replace( '/[^a-z0-9-]/', '-', strtolower( $domain ) );
        $namespace = preg_replace( '/-+/', '-', $namespace );
        $namespace = trim( $namespace, '-' );

        return $namespace;
    }

    /**
     * Get the MX-Reginald API token from settings.
     *
     * @return string API token or empty string.
     */
    private function get_api_token() {
        $options = get_option( 'mx_cogify_settings', array() );
        return $options['reginald_api_token'] ?? '';
    }

    /**
     * Check subscription status with MX-Reginald.
     *
     * @return array|WP_Error Subscription status.
     */
    public function check_subscription_status() {
        $token = $this->get_api_token();
        if ( empty( $token ) ) {
            return new WP_Error( 'no_token', 'API token not configured.' );
        }

        $response = wp_remote_get(
            $this->status_url,
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( 200 !== $code ) {
            return new WP_Error( 'api_error', $body['error'] ?? "HTTP $code" );
        }

        return $body;
    }

    /**
     * Check if the manifest is accessible at .well-known/mx-cogs.json.
     *
     * @return array Status information.
     */
    public function check_status() {
        $registration = get_option( 'mx_cogify_registration', array() );
        $manifest_url = home_url( '/.well-known/mx-cogs.json' );

        // Test self-fetch of manifest.
        $response = wp_remote_get( $manifest_url, array( 'timeout' => 10 ) );
        $manifest_reachable = ! is_wp_error( $response ) &&
            200 === wp_remote_retrieve_response_code( $response );

        // Test MX-Reginald for our namespace.
        $namespace  = $this->get_namespace();
        $reginald_response = wp_remote_get(
            'https://reginald.allabout.network/api/v1/publishers.json',
            array( 'timeout' => 10 )
        );

        $reginald_registered = false;
        if ( ! is_wp_error( $reginald_response ) ) {
            $publishers = json_decode( wp_remote_retrieve_body( $reginald_response ), true );
            if ( is_array( $publishers['publishers'] ?? array() ) ) {
                foreach ( $publishers['publishers'] as $pub ) {
                    if ( ( $pub['namespace'] ?? '' ) === $namespace ) {
                        $reginald_registered = true;
                        break;
                    }
                }
            }
        }

        return array(
            'namespace'           => $namespace,
            'manifest_url'        => $manifest_url,
            'manifest_reachable'  => $manifest_reachable,
            'reginald_registered' => $reginald_registered,
            'local_registration'  => $registration,
        );
    }
}
