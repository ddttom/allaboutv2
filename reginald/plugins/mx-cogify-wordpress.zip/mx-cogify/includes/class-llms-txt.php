<?php
/**
 * LLMs.txt — generates and serves the /llms.txt discovery file.
 *
 * @mx:status draft
 * @mx:contentType product
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MX_Cogify_Llms_Txt {

    /**
     * Register rewrite rule for /llms.txt.
     */
    public static function register_rewrite() {
        add_rewrite_rule( '^llms\.txt$', 'index.php?mx_llms_txt=1', 'top' );
        add_filter( 'query_vars', function ( $vars ) {
            $vars[] = 'mx_llms_txt';
            return $vars;
        } );
    }

    /**
     * Serve llms.txt content.
     */
    public static function serve() {
        if ( ! get_query_var( 'mx_llms_txt' ) ) {
            return;
        }

        header( 'Content-Type: text/plain; charset=utf-8' );
        header( 'X-Robots-Tag: noindex' );

        echo self::build_content();
        exit;
    }

    /**
     * Generate llms.txt file content.
     */
    public static function generate() {
        // Store generated content for static serving if needed.
        $content = self::build_content();
        update_option( 'mx_cogify_llms_txt', $content );
        return $content;
    }

    /**
     * Build the llms.txt content.
     */
    private static function build_content() {
        $options      = get_option( 'mx_cogify_settings', array() );
        $registration = get_option( 'mx_cogify_registration', array() );

        $site_name   = $options['site_name'] ?? get_bloginfo( 'name' );
        $description = get_bloginfo( 'description' );
        $org_name    = $options['org_name'] ?? $site_name;
        $author      = $options['author_name'] ?? '';
        $url         = home_url( '/' );
        $policy      = $options['content_policy'] ?? 'extract-with-attribution';
        $status      = $options['default_status'] ?? 'active';
        $registered  = ! empty( $registration['registered'] ) ? 'Yes' : 'No';

        // Count content.
        $post_count    = wp_count_posts( 'post' );
        $page_count    = wp_count_posts( 'page' );
        $product_count = post_type_exists( 'product' ) ? wp_count_posts( 'product' ) : null;

        $output  = "# {$site_name}\n\n";
        $output .= "> {$description}\n\n";

        $output .= "## About\n";
        $output .= "{$org_name} — {$url}\n\n";

        $output .= "## Content\n";
        $output .= "- Blog posts: {$post_count->publish} published\n";
        $output .= "- Pages: {$page_count->publish} published\n";

        if ( $product_count ) {
            $output .= "- Products: {$product_count->publish} published\n";
        }

        $output .= "\n## MX Metadata\n";
        $output .= "- Status: {$status}\n";
        $output .= "- Content Policy: {$policy}\n";
        $output .= "- Registered on Reginald: {$registered}\n";
        $output .= "- Plugin: MX Cogify v" . MX_COGIFY_VERSION . "\n";

        if ( $author ) {
            $output .= "\n## Contact\n";
            $output .= "- Author: {$author}\n";
            $output .= "- URL: {$url}\n";
        }

        return $output;
    }
}
